f=open('test_localsystem.txt','w')
f.write('I have run\n')
f.close()
