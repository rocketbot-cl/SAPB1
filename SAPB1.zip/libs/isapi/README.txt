A Python ISAPI extension.  Contributed by Phillip Frantz, and is
Copyright 2002-2003 by Blackdog Software Pty Ltd.

See the 'samples' directory, and particularly samples\README.txt

You can find documentation in the PyWin32.chm file that comes with pywin32 - 
you can open this from Pythonwin->Help, or from the start menu.